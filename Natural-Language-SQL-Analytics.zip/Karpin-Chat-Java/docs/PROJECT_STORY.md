# Project story

During the ACM India Summer School on Generative AI for Text at IIT Gandhinagar, I worked on a hackathon problem around long-table question answering. I later independently reimplemented the core idea in Java, replacing the Python/Streamlit approach with a Spring Boot backend, embedded SQL data layer, LLM-driven text-to-SQL service, and a React dashboard UI.

Do not say the Java implementation was the original Summer School submission if it was built later. Do not claim the original team’s Python code as your own.
