# Natural Language SQL Analytics — Karpin Chat (Java)

Ask questions about tabular data in plain English and explore the answer without writing SQL by hand. Karpin Chat uses a Java/Spring Boot backend to request a SQL statement from a Groq-hosted language model, validates the generated statement as read-only, executes it against an embedded H2 database, and displays the answer and generated SQL in a React interface.

> **Dataset note:** The included sample data concerns electoral bonds. The application is currently configured around this dataset and its `merged_bonds` table; it is not yet a general-purpose CSV upload tool.

## Features

- Natural-language questions converted into SQL by a configurable Groq model.
- Read-only query guard before SQL execution.
- Java 17, Spring Boot, Spring JDBC and an in-memory H2 database.
- React/Vite chat interface with sample questions and generated-SQL display.
- CSV data loaded into H2 automatically when the backend starts.

## Technology stack

- **Backend:** Java 17, Spring Boot 3.3.2, Spring Web, Spring WebFlux/WebClient, Spring JDBC, Apache Commons CSV
- **Database:** H2 in-memory database (PostgreSQL compatibility mode)
- **LLM API:** Groq API; default model `llama-3.3-70b-versatile`
- **Frontend:** React, Vite, JavaScript and CSS

## Prerequisites

Install the following before running the project:

1. **JDK 17** (or compatible Java 17 distribution).
2. **Apache Maven 3.8+**.
3. **Node.js and npm** (a current LTS release is recommended).
4. A **Groq API key** for natural-language-to-SQL requests. Get one through the official [Groq Console](https://console.groq.com/).

Check your installations:

```bash
java -version
mvn -version
node --version
npm --version
```

## Configuration

The backend reads the API key from the `GROQ_API_KEY` environment variable. It is not necessary to put the key in source code or commit it to Git.

Optional environment variable:

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `GROQ_API_KEY` | Yes for asking questions | Empty | Authenticates requests to the Groq API |
| `GROQ_MODEL` | No | `llama-3.3-70b-versatile` | Selects the Groq model used to generate SQL |

### Set environment variables

**macOS/Linux (bash or zsh):**

```bash
export GROQ_API_KEY="your_groq_api_key_here"
# Optional:
export GROQ_MODEL="llama-3.3-70b-versatile"
```

**Windows PowerShell:**

```powershell
$env:GROQ_API_KEY = "your_groq_api_key_here"
# Optional:
$env:GROQ_MODEL = "llama-3.3-70b-versatile"
```

Set these variables in the same terminal/session used to start the backend. Replace the example value with your own key; do not publish it.

## Run locally

Run the backend and frontend in **two separate terminals** from the repository root.

### 1. Start the backend

```bash
cd backend
mvn spring-boot:run
```

The Spring Boot API starts on `http://localhost:8080`. On startup, it reads the two bundled CSV files and builds the H2 tables. The database is in memory, so the data is loaded again each time the backend restarts.

Check the health endpoint in a browser or with curl:

```bash
curl http://localhost:8080/api/health
```

Expected response:

```text
Karpin Chat Java is running
```

### 2. Start the frontend

In a second terminal, from the repository root:

```bash
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:5173`). Keep the backend running while using the UI.

## How to use it

1. Start the backend and frontend as described above.
2. Open the Vite URL in your browser.
3. Choose one of the sample questions or type a question about the included electoral-bond dataset.
4. Submit the question and review the answer.
5. Expand **View generated SQL** to inspect the SQL statement and execution time.

Example questions shown in the interface include:

- Which political party received the highest total bond value?
- How many bonds were encashed by a particular political party?
- What is the maximum denomination for a political party?
- Show the top 5 purchasers by total bond value.

## API quick reference

### `GET /api/health`

Returns a simple health/status message.

### `POST /api/ask`

Request body:

```json
{
  "question": "Which political party received the highest total bond value?"
}
```

The response includes the answer, generated SQL, elapsed time in milliseconds, and dataset label. Errors are returned as a bad-request response with an error message.

## Project structure

```text
.
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/akhila/karpin/
│       │   ├── config/       # Groq client and CSV/H2 data loading
│       │   ├── controller/  # REST endpoints
│       │   ├── dto/         # API request/response objects
│       │   └── service/     # SQL generation, validation and execution
│       └── resources/
│           ├── application.properties
│           └── data/        # Bundled CSV datasets
├── frontend/
│   ├── package.json
│   └── src/                 # React UI and styles
└── docs/
    └── PROJECT_STORY.md
```

## Security and responsible use

- **Never commit API keys, passwords, access tokens, or `.env` files.** The repository's `.gitignore` excludes `.env`; keep secrets in environment variables or a secret manager.
- If a key is ever committed or exposed, revoke/rotate it in the provider console immediately. Removing it in a later commit does not make the leaked key safe again.
- The backend has a query guard intended to allow read-only SQL only. Treat this as a safety layer, not a complete security boundary; review and test it before exposing the service to untrusted users or deploying it publicly.
- The API is configured for a local frontend origin (`http://localhost:5173`) and is intended for local development as provided. Review CORS, authentication, rate limiting, error handling, and deployment settings before hosting it.
- The Groq API receives the question and relevant prompt context. Do not send personal, confidential, regulated, or otherwise sensitive data unless you are authorized to do so and have reviewed the provider's terms and privacy requirements.
- The bundled CSVs are part of the example project. Review the data source, licensing, provenance, and any applicable use restrictions before redistributing or using the data commercially.

## Limitations

- The current prompt and SQL schema are tailored to the included electoral-bond data.
- H2 is in-memory; there is no persistent database between restarts.
- The frontend calls the local backend URL directly. Production deployment will require configuration appropriate to the hosting environment.
- LLM output may be incorrect. Validate results before relying on them for consequential decisions.

## Project context

This Java implementation is an independent reimplementation of a long-table question-answering idea explored during the ACM India Summer School on Generative AI for Text. It should not be represented as the original Summer School submission or as another team's source code.

## License

No license has been added yet. Unless a license is added, others do not automatically receive permission to reuse, modify, or redistribute the project. Add a license only after deciding which terms you want to apply.
